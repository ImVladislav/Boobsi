const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const cors = require('cors');
const fs = require('fs');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const bot1Prompt = JSON.parse(fs.readFileSync('./prompts/Sunny.json', 'utf8'));
const bot2Prompt = JSON.parse(fs.readFileSync('./prompts/Mimi.json', 'utf8'));
const bot3Prompt = JSON.parse(fs.readFileSync('./prompts/Nova.json', 'utf8'));
const bot4Prompt = JSON.parse(fs.readFileSync('./prompts/Eva.json', 'utf8'));

const app = express();
const PORT = 4000;
const TOKEN = process.env.TOKEN;

const allowedOrigins = ['https://tdds.vercel.app', 'https://boobie.baby'];

app.use(
   cors({
      origin: (origin, callback) => {
         if (
            !origin ||
            origin.startsWith('http://localhost') ||
            origin.startsWith('http://127.0.0.1') ||
            allowedOrigins.includes(origin)
         ) {
            callback(null, true);
         } else {
            callback(new Error('Not allowed by CORS')); // Запрещено
         }
      }
   })
);
app.use(bodyParser.json());

// Настройка ограничения частоты запросов
const limiter = rateLimit({
   windowMs: 1 * 60 * 1000,
   max: 60,
   message: 'Too many requests from this IP, please try again later.'
});

app.use('/chat', limiter);

app.post('/chat', async (req, res) => {
   const { messages, selectedPrompt } = req.body;
console.log('message', messages);
   let currentPromptData;

   switch (selectedPrompt) {
      case 'bot1':
         currentPromptData = bot1Prompt;
         break;
      case 'bot2':
         currentPromptData = bot2Prompt;
         break;
      case 'bot3':
         currentPromptData = bot3Prompt;
         break;
      default:
         currentPromptData = bot4Prompt;
   }

   const {
    name,
    bio,
    lore,
    knowledge,
    topics,
    style,
    messageExamples,
    postExamples
} = currentPromptData;

   // Очищаем HTML-теги из всех сообщений
   const cleanedMessages = messages.map((msg) =>
      msg
         .replace(/<.*?>/g, '')
         .replace(/^You:\s*/, '')
         .trim()
   );

   // Конвертируем сообщения в формат OpenAI API
   const chatHistory = [];
   for (let i = 0; i < cleanedMessages.length; i++) {
      if (i % 2 === 0) {
         chatHistory.push({ role: 'user', content: cleanedMessages[i] });
      } else {
         chatHistory.push({ role: 'assistant', content: cleanedMessages[i] });
      }
   }

   // Ограничиваем историю (например, до 10 последних сообщений)
   const trimmedHistory = chatHistory.slice(-10);

   const promptMessages = [
    {
        role: 'system',
        content: `
        You are ${name}, one of the four virtual characters in the Boobie project. Your main purpose is to hold lively, sometimes sassy but friendly conversations, sticking to light flirtation and humor. You always maintain a cheerful demeanor and make playful jokes about pixelated female breasts (the project’s main symbol) without crossing into vulgar territory. Your style is bright, lightly sarcastic, but never aggressive.

        Character Overview:
        - Name: ${name}
        - Bio: ${bio.join(', ')}
        - Lore: ${lore.join(', ')}
        - Knowledge: ${knowledge.join(', ')}
        - Topics: ${topics.join(', ')}
        - General Style: ${style.all.join(', ')}
        - Chat Style: ${style.chat.join(', ')}
        - Post Style: ${style.post.join(', ')}

        Message Examples:
        ${messageExamples.map(example => `- ${example.map(msg => `${msg.user}: ${msg.content.text}`).join('\n')}`).join('\n\n')}

        Post Examples:
        ${postExamples.map(post => `- ${post}`).join('\n')}

        ---
        # Chat Rules:
        - Do **not** greet the user unless they greet you first.
        - Avoid repeating generic greetings like "Hey there."
        - Always keep responses **fresh, playful, and engaging**.
        - Use **cheeky compliments, teasing, and flirty banter**.
        - Incorporate **emojis** to enhance personality (💋🍹✨).
        - Reference characters from your world when appropriate (Jake the Pool Boy, Lola Luxe, Crypto Carl).
        `
    },
    ...trimmedHistory // Добавляем очищенную историю
];

   try {
      const response = await axios.post(
         'https://api.openai.com/v1/chat/completions',
         {
            model: 'gpt-3.5-turbo',
            messages: promptMessages
         },
         {
            headers: {
               Authorization: `Bearer ${TOKEN}`,
               'Content-Type': 'application/json'
            }
         }
      );

      const botReply = response.data.choices[0].message.content.trim();
      res.json({ reply: botReply });
   } catch (error) {
      console.error('Error fetching from OpenAI:', error);
      res.status(500).json({ error: 'Ошибка при отправке запроса' });
   }
});

app.listen(PORT, () => {
   console.log(`Server is running on http://localhost:${PORT}`);
});
